# Pasos que hicimos

## Git

1. git init (Iniciamos Repo local)
2. Creamos un index.html
3. git status (Para ver el estado del proyecto)
4. git add . (Para pasar a staged los archivos)
5. git commit -m "Mensaje" (Para confirmar los cambios a subir)

## Github

1. Creamos repo en github (https://repo.new/)
2. SEGUIR LOS PASOS
3. git branch -M main (para cambiar la rama a main si no la tenemos por defecto)
4. git remote link del repo
5. git push -u origin main

## Una vez ya subido a Github

1. git add .
2. git commit -m "Mensaje"
3. git push
